@extends('layouts.plantilla')

@section('tituloPagina', 'Mis Favoritos')