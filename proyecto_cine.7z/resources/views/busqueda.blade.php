@extends('layouts.plantilla')

@section('tituloPagina', 'Búsqueda')