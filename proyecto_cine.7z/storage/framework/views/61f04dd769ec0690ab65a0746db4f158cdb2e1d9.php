<?php $__env->startSection('tituloPagina', $pelicula->title); ?>

<?php $__env->startSection('cuerpo'); ?>
<h3><?php echo e($pelicula->title); ?> (<?php echo e($pelicula->release_date); ?>)</h3>
<p>
    <?php echo e($pelicula->runtime); ?>&#39; |
    <?php $__currentLoopData = $pelicula->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($genre === end($pelicula->genres)): ?>
            <a href="/genero?id=<?php echo e($genre["id"]); ?>"><?php echo e($genre["name"]); ?></a>
        <?php else: ?>
            <a href="/genero?id=<?php echo e($genre["id"]); ?>"><?php echo e($genre["name"]); ?></a>,
        <?php endif; ?>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> | 
    <a target='_blank' href='<?php echo e($pelicula->imdb_id); ?>'>IMDB</a> | 
    <a target='_blank' href='<?php echo e($pelicula->homepage); ?>'>Página Oficial</a>

</p>
<p>
        Inversión: <?php echo e($pelicula->budget); ?>$ || Ingresos: <?php echo e($pelicula->revenue); ?>$
</p>
<table>
    <tr>
        <td><img src="<?php echo e($pelicula->poster_path); ?>" height="405px" style="vertical-align: baseline;"></td>
        <?php if($pelicula->trailer!=null): ?>
        <td>
                <iframe width="720" height="405" src="<?php echo e($pelicula->trailer); ?>?rel=0&amp;controls=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>    
        </td>
        <?php endif; ?>
        <td>
            
            Popularidad: <?php echo e($pelicula->popularity); ?><br/>
            Valoración Media: <?php echo e($pelicula->vote_average); ?><sub>/10</sub><br/>
        </td>
    
    </tr>

</table>
<hr>
<?php echo e($pelicula->overview); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>