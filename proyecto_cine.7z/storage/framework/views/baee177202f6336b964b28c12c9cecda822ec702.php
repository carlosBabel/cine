<?php $__env->startSection('tituloPagina', $arrayJson["title"]); ?>

<?php $__env->startSection('cuerpo'); ?>
<table>

    <tr>
        <td style="padding: 20px;"><img src='https://image.tmdb.org/t/p/w500/<?php echo e($arrayJson["poster_path"]); ?>' width='200px'></td>
        <td>
        Título: <?php echo e($arrayJson["title"]); ?><br/>
        Resumen corto: <?php echo e($arrayJson["tagline"]); ?><br/>
        <a href='<?php echo e($arrayJson["homepage"]); ?>'>Página Oficial</a><br/>
        <a target=blank href='https://www.imdb.com/title/<?php echo e($arrayJson["imdb_id"]); ?>'>IMDB</a><br/>
        Resumen: <?php echo e($arrayJson["overview"]); ?><br/>
        <?php (setlocale(LC_MONETARY, 'en_US')); ?>
        <?php ($caja = number_format(floatval($arrayJson["budget"]), 0)); ?>
        Caja: <?php echo e($caja); ?>€<br/>
        Popularidad: <?php echo e($arrayJson["popularity"]); ?><br/>
        Fecha de estreno: <?php echo e($arrayJson["release_date"]); ?><br/>
        Valoración Media: <?php echo e($arrayJson["vote_average"]); ?></td></tr>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>