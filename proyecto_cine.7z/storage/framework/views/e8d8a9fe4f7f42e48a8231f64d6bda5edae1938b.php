<?php $__env->startSection('tituloPagina', 'Búsqueda'); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>