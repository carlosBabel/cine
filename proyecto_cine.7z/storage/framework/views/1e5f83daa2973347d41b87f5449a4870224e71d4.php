<?php $__env->startSection('tituloPagina', 'Popular'); ?>

<?php $__env->startSection('cuerpo'); ?>
<?php ($contador=1); ?>
    <div class="container">
        <div class="row">
        <?php for($i=0;$i<count($arrayJson["results"]);$i++): ?>
            <?php if($contador==5): ?>
                <div class="row">
                <?php ($contador=1); ?>
            <?php endif; ?>
            <?php ($fecha = date_create($arrayJson["results"][$i]["release_date"])); ?>
                <div class="col-md-3">
                    <div class="card mb-3 box-shadow" style="width: 18rem;">
                        <img class="card-img-top" height="100px" src="https://image.tmdb.org/t/p/w500/<?php echo e($arrayJson["results"][$i]["poster_path"]); ?>" alt="Sin carátula"> 
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e(($arrayJson["results"][$i]["title"])); ?></h5>
                            <p class="card-text">Fecha de estreno:<?php echo e(date_format($fecha, 'd/m/y')); ?></p>
                            <a href="/pelicula?id=<?php echo e(($arrayJson["results"][$i]["id"])); ?>" class="btn btn-primary">Más detalles</a>
                        </div>
                    </div>
                </div>
                    <?php ($contador++); ?>
                <?php if($contador==5): ?>
                </div>   
                <?php endif; ?>
        <?php endfor; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>