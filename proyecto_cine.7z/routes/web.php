<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/españa', 'MenuController@spain');
Route::get('/busqueda', 'MenuController@busqueda');
Route::get('/favoritos', 'MenuController@favoritos');
Route::get('/popular', 'MenuController@popular');
Route::get('/cartelera', 'MenuController@cartelera');
Route::get('/', 'MenuController@cartelera');
Route::get('/pelicula', 'MenuController@pelicula');
Route::get('/genero', 'MenuController@genero');

// Route::resource('pelicula', 'PeliculaController');

